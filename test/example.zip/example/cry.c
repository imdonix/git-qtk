void cry(int* ptr)
{
    *ptr = 2;
}

void a(void) {}

int b(void) {}

int c(void) {}