int bit(int in)
{
    return in + in; 
}

int a() {}
int b() {}